import State.State
import json.JSON.{JList, JObject, JString}
import json.JSONReader
import json.Syntax._

import scala.annotation.tailrec
import scala.io.Source

object Main extends App {

  type Graph = Map[String, Component]

  val (graphJSON, eventsJSON) = (args(0), args(1))
  val PROPAGATED = "propagated"

  val events = JSONReader.read(Source.fromFile(eventsJSON).mkString) \ "events" match {
    case jList: JList => jList.values map {
      case JObject(("timestamp", timestamp: JString), ("component", component: JString),
                   ("check_state", checkState: JString), ("state", state: JString)) =>
        Event(timestamp, component, checkState, State.withName(state))
    }
    case _ => List()
  }

  val graph = (JSONReader.read(Source.fromFile(graphJSON).mkString) \ "components" match {
    case jList: JList => jList.values map {

      case JObject(("id", id: JString), ("own_state", ownState: JString), ("derived_state", derivedState: JString),
       ("check_states", checkStates: JObject), ("depends_on", dependsOn: JList)) =>
        val checks = checkStates.values.map {
          case (key, JString(state)) => key -> State.withName(state)
        }.toMap

        id.string -> Component(id, State.withName(ownState), State.withName(derivedState), checks, List(),
          dependsOn.getAsStrings)

      case JObject(("id", id: JString), ("own_state", ownState: JString), ("derived_state", derivedState: JString),
       ("check_states", checkStates: JObject), ("dependency_of", dependencyOf: JList)) =>
        val checks = checkStates.values.map {
          case (key, JString(state)) => key -> State.withName(state)
        }.toMap

        id.string -> Component(id, State.withName(ownState), State.withName(derivedState), checks,
          dependencyOf.getAsStrings, List())

      case JObject(("id", id: JString), ("own_state", ownState: JString), ("derived_state", derivedState: JString),
       ("check_states", checkStates: JObject), ("depends_on", dependsOn: JList), ("dependency_of", dependencyOf: JList)) =>
        val checks = checkStates.values.map {
          case (key, JString(state)) => key -> State.withName(state)
        }.toMap

        id.string -> Component(id, State.withName(ownState), State.withName(derivedState), checks,
          dependencyOf.getAsStrings, dependsOn.getAsStrings)
    }
  }).toMap

  println(JObject(
    ("graph", JObject(
      ("components", JList(
        applyEvents(graph, events).map {
          case Component(id, ownState, derivedState, checkStates, List(), dependsOn) =>
            JObject(
              ("id", JString(id)),
              ("own_state", JString(ownState.toString)),
              ("derived_state", JString(derivedState.toString)),
              ("check_state", JObject(checkStates.map{ case (key, state) => (key, JString(state.toString)) }.toSeq:_*)),
              ("depends_on", JList(dependsOn.map(JString):_*))
            )
          case Component(id, ownState, derivedState, checkStates, dependencyOf, List()) =>
            JObject(
              ("id", JString(id)),
              ("own_state", JString(ownState.toString)),
              ("derived_state", JString(derivedState.toString)),
              ("check_state", JObject(checkStates.map{ case (key, state) => (key, JString(state.toString)) }.toSeq:_*)),
              ("dependency_of", JList(dependencyOf.map(JString):_*))
            )
          case Component(id, ownState, derivedState, checkStates, dependencyOf, dependsOn) =>
            JObject(
              ("id", JString(id)),
              ("own_state", JString(ownState.toString)),
              ("derived_state", JString(derivedState.toString)),
              ("check_state", JObject(checkStates.map{ case (key, state) => (key, JString(state.toString)) }.toSeq:_*)),
              ("depends_on", JList(dependsOn.map(JString):_*)),
              ("dependency_of", JList(dependencyOf.map(JString):_*))
            )
        }:_*
      ))
    ))
  ).write)

  def applyEvents(graph: Graph, events: Seq[Event]): Seq[Component] = {

    @tailrec
    def applyEventsRec(events: Seq[Event], acc: Graph): Graph = events match {
      case Seq() => acc
      case event +: tail =>
        val (allEvents, accGraph) = acc.get(event.component).fold((tail, acc)) { component =>
          val (addedEvents, newComponent) = calculateState(component, event)
          (addedEvents ++: tail, acc + (component.id -> newComponent))
        }

        applyEventsRec(allEvents, accGraph)
    }

    applyEventsRec(events, graph).values.toList
  }

  private def calculateState(component: Component, event: Event): (Seq[Event], Component) = {
    val newState = determineStateUpdate(component, event)

    (newState.dependentEvents, component.copy(checkStates = newState.checkStates, ownState = newState.ownState,
      derivedState = newState.derivedState))
  }

  private def determineStateUpdate(component: Component, event: Event): StateUpdate = {
    event.checkState match {
      case PROPAGATED =>

        val (derivedState, dependentEvents) = if(component.ownState < event.state && event.state > State.Clear) {
          (event.state, component.dependencyOf.map( componentId => Event(event.timestamp, componentId, PROPAGATED, event.state)))
        } else (State.NoData, Seq[Event]())

        StateUpdate(
          checkStates = component.checkStates,
          ownState = component.ownState,
          derivedState = derivedState,
          dependentEvents = dependentEvents
        )

      case checkState @ _ =>
        val checkStates = component.checkStates + (checkState -> event.state)
        val ownState = checkStates.values.fold(State.NoData)((acc, state) => if(acc > state) acc else state)
        val (derivedState, dependentEvents) = if(ownState >= State.Warning && component.derivedState <= State.Clear) {
          (ownState, component.dependencyOf.map( componentId => Event(event.timestamp, componentId, PROPAGATED, ownState)))
        // TODO : Own state no_data, derived state warning.. receives clear metrics which updates state, dependency still in warning.
        // TODO : should stay in warning state.
        } else if (ownState <= State.Clear && component.derivedState >= State.Warning) {
          (State.NoData, component.dependencyOf.map( componentId => Event(event.timestamp, componentId, PROPAGATED, ownState)))
        } else (State.NoData, Seq[Event]())

        StateUpdate(
          checkStates = checkStates,
          ownState = ownState,
          derivedState = derivedState,
          dependentEvents = dependentEvents
        )

    }
  }

/*
1. The check states. Each components has zero, one or multiple of these. (In StackState
they represent states that are calculated by running checks on monitoring data, which is
outside the scope of this assessment so you can just change them yourself.) These check
states can be expected to change all the time. The check states influence the own state of
the component.
2. The own state, singular, is the highest state of all check states. It is not affected by
anything other then the check states. If the component has no check states the own state
is no_data . (In StackState the own state represents the state that the component itself
reports.) The own state of a component influences the derived state of the component

3. The derived state, singular, is either A) the own state from warning and up or if higher B)
the highest of the derived states of the components it depends on. Clear state does not
propagate, so if the own state of a component is clear or no_data and its dependent

derived states are clear or no_data then the derived state is set to no_data.

Take a dependency graph with two nodes. A component named "db" and a component
named "app". The app is dependent on the db. The db has two check states. One of the
check states named "CPU load" of the db goes to the warning state. The own state of the db
becomes warning. The derived state of the db and app become warning.
 */
}

case class StateUpdate(checkStates: Map[String, State], ownState: State, derivedState: State, dependentEvents: Seq[Event])
case class Component(id: String, ownState: State, derivedState: State, checkStates: Map[String, State],
                     dependencyOf: List[String], dependsOn: List[String])
case class Event(timestamp: String, component: String, checkState: String, state: State)

object State extends Enumeration {
  type State = Value
  val NoData: State = Value(1, "no_data")
  val Clear: State = Value(2, "clear")
  val Warning: State = Value(3, "warning")
  val Alert: State = Value(4, "alert")
}